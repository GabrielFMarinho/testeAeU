﻿using System;

public class PersonViewModel
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Sex { get; set; }
    public string City { get; set; }
}
