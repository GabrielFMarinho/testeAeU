﻿namespace AuERegister.FrontEnd.ViewModel
{
    public class ContactViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Sex { get; set; }
        public DateTime Date { get; set; }
        public string City { get; set; }
    }
}
